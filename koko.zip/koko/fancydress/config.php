<?php
define('RAZORPAY_KEY', 'rzp_test_abc123xyz'); // Replace with your Razorpay key
define('RAZORPAY_SECRET', 'your_secret_key'); // Replace with your Razorpay secret
